package cg;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Space {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpaceAdder s=st->System.out.println(st.replaceAll("", " "));
		s.sAdder("Ariz Ahmad Usmani");
		
	}

}
