package cg;

public interface SpaceAdder {
	public void sAdder(String s);
}
