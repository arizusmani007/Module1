package cg;

public interface UserPass {
	public void check(String id, String pass);
}
