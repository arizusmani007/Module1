package cg;
@FunctionalInterface
public interface FindP{
		
		public double findPow(int num1,int num2);
		
	}
