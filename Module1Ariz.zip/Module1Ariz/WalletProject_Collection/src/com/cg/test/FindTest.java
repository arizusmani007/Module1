package com.cg.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

import java.util.*;


import com.cg.*;
import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.exception.InsufficientFundException;
import com.cg.service.AccountService;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;

public class FindTest {

	private AccountService ser;
	private AccountDAO dao;
	@Test
	public void setup() {
		ser = new AccountService();
		dao = EasyMock.createMock(AccountDAO.class);
		ser.setDAO(dao);
		Account ob=new Account();
		long n=9999999999L;
		EasyMock.expect
		(dao.findAccount(n))
		.andReturn(ob);
		EasyMock.replay(dao);
		assertTrue(ser.findAccount(n)!=null);
		EasyMock.verify(dao);
	}
}
