package com.cg.test;
import com.cg.service.*;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

import java.util.*;


import com.cg.*;
import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.exception.InsufficientFundException;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;

public class WalletTest {

	private AccountService ser;
	private AccountDAO dao;
	@BeforeEach
	public void setup() {
		ser = new AccountService();
		dao = EasyMock.createMock(AccountDAO.class);
		
		
	}
	@Test
	
		public void testfindaccount() {
			Account ob=new Account();
			long n=9999999999L;
			ser.findAccount(n);
			EasyMock.expect
			(dao.findAccount(n))
			.andReturn(ob);
			EasyMock.replay(dao);
			assertTrue(ser.findAccount(n)!=null);
			EasyMock.verify(dao);
		}
	@Test
	void testwithdraw() throws InsufficientFundException {
		
		System.out.println("for withdraw");
		Account a=new Account();
		a.setBalance(5000);
		AccountService service=new AccountService();
		assertEquals(4500,service.withdraw(a,500));
	}
	@Test
	void testdeposit(){
		
		System.out.println("for deposit");
		Account a=new Account();
		a.setBalance(5000);
		AccountService service=new AccountService();
		assertEquals(5500,service.deposit(a, 500));
		}
	@Test
	void testtransfer(){
		
		System.out.println("for transfer");
		Account a=new Account();
		Account b=new Account();
		a.setBalance(5000);
		b.setBalance(6000);
		AccountService service=new AccountService();
		
		assertEquals(4500.0,service.transferMoney(a,b,500));
		assertEquals(5500.0,service.transferMoney(a,b,500));
		}
	@Test
	void testtax(){
		
		System.out.println("for tax");
		AccountService service=new AccountService();
		assertEquals(50.0,service.calculateTax(0.05, 1000));
		}
	
}
